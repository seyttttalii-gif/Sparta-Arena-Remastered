# Sparta Arena 3D — geliştirilmiş kaynak paketi

Bu paket yeni bir bağımsız Python/Ursina tabanı sağlar; önceki V57 oyununun orijinal kaynak dosyaları bu pakete dahil değildir.

## Özellikler
- İlk çalıştırmada 13 saniyelik sinematik açılış; ATLA düğmesi.
- Açılış tamamlandıktan sonra sonraki açılışlarda doğrudan ana menü.
- Ana menüden TANITIMI OYNAT ile açılışı tekrar izleme.
- Mod seçimi ve dört harita seçimi.
- Arena döngüsü için basit hareket/saldırı/savunma ve düşmanlar.
- Dünya fethi, şehirler, deniz fethi, balıkçılık, mağaza, iksirler ve başarımlar için kalıcı menüler ve basit kayıt sistemi.
- Ayarlardan hareket/savunma tuşlarını yeniden atama.
- Oyun ilerlemesi `%LOCALAPPDATA%\SpartaArena\save.json` konumunda saklanır.

## Windows'ta kaynak koddan çalıştırma
Python 3.11 yükledikten sonra terminalde:

```powershell
python -m pip install -r requirements.txt
python main.py
```

## Windows EXE oluşturma

```powershell
python -m PyInstaller --noconfirm --clean --windowed --onedir --name SpartaArena --collect-all ursina --collect-all panda3d --add-data "assets;assets" main.py
```

Çıktı `dist/SpartaArena/SpartaArena.exe` konumunda olacaktır. EXE klasörünün tamamını birlikte taşıyın.

## Önemli
Bu kaynak paketi özgün V57 kaynak kodunun yerini alan bir başlangıç sürümüdür; eski V57 özelliklerinin tamamını birebir kopyaladığı söylenemez. Menü ekranları ve kayıtlar mevcuttur; fetih/ekonomi sistemleri basitleştirilmiş temeldir.

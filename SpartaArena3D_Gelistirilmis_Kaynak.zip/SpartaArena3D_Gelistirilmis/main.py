import json
import math
import os
import random
import sys
from pathlib import Path

from ursina import *

APP_NAME = "Sparta Arena 3D"

def resource_path(relative):
    """Return an asset path in source and PyInstaller builds."""
    root = getattr(sys, "_MEIPASS", str(Path(__file__).resolve().parent))
    return str(Path(root) / relative)

# Save data lives outside the install folder, so it survives game updates.
SAVE_DIR = Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / "SpartaArena"
SAVE_FILE = SAVE_DIR / "save.json"
DEFAULT_SAVE = {
    "intro_seen": False,
    "gold": 100,
    "potions": {"healing": 1, "strength": 0},
    "achievements": [],
    "cities": [],
    "seas": [],
    "fish": 0,
    "wins": 0,
    "controls": {"forward": "w", "back": "s", "left": "a", "right": "d", "attack": "left mouse down", "block": "shift"},
    "audio": True,
}

def load_save():
    SAVE_DIR.mkdir(parents=True, exist_ok=True)
    if SAVE_FILE.exists():
        try:
            current = json.loads(SAVE_FILE.read_text(encoding="utf-8"))
            merged = dict(DEFAULT_SAVE)
            merged.update(current)
            merged["potions"] = {**DEFAULT_SAVE["potions"], **current.get("potions", {})}
            merged["controls"] = {**DEFAULT_SAVE["controls"], **current.get("controls", {})}
            return merged
        except Exception:
            pass
    return dict(DEFAULT_SAVE)

def save_game():
    SAVE_DIR.mkdir(parents=True, exist_ok=True)
    SAVE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

state = load_save()
app = Ursina(title="SPARTA ARENA - 3D", borderless=False, fullscreen=False)
window.size = (1280, 720)
window.center_on_screen()
window.color = color.rgb(10, 12, 18)
window.exit_button.visible = False
window.fps_counter.enabled = False
mouse.visible = True

# Lighting and arena architecture; the background remains behind menus and gameplay.
AmbientLight(color=color.rgba(145, 126, 105, 255))
key_light = DirectionalLight(color=color.rgba(255, 205, 150, 255))
key_light.look_at(Vec3(1, -2, -1))
Entity(model="plane", scale=(100, 1, 100), y=-1.25, texture="white_cube", texture_scale=(30, 30), color=color.rgb(37, 38, 38))
Entity(model="cylinder", scale=(42, 1.0, 42), y=-0.8, color=color.rgb(63, 48, 39))
Entity(model="cylinder", scale=(31, 0.75, 31), y=-0.15, color=color.rgb(132, 94, 61))
Entity(model="cylinder", scale=(29.5, 0.14, 29.5), y=0.25, color=color.rgb(190, 144, 84))
Entity(model="cylinder", scale=(28.5, 0.12, 28.5), y=0.34, color=color.rgb(133, 96, 64))
for i in range(20):
    angle = (math.tau * i) / 20
    x, z = math.cos(angle) * 23, math.sin(angle) * 23
    Entity(model="cube", position=(x, 2.2, z), scale=(1.05, 5.8, 1.05), color=color.rgb(87, 74, 65))
    Entity(model="cube", position=(x, 5.2, z), scale=(1.35, .45, 1.35), color=color.rgb(129, 103, 83))
    if i % 2 == 0:
        Entity(model="cube", position=(x, 4.2, z), scale=(1.0, 1.9, .09), color=color.rgb(93, 14, 19))
# Center gate / stairs as a landmark in the arena.
Entity(model="cube", position=(0, 1.5, 13), scale=(5, 4, .7), color=color.rgb(63, 19, 20))
Entity(model="cube", position=(0, 3.65, 13), scale=(6.2, .4, 1.1), color=color.rgb(124, 91, 63))

try:
    intro_audio = Audio(resource_path("assets/audio/intro_theme.wav"), loop=False, autoplay=False, auto_destroy=False)
except Exception:
    intro_audio = None

def play_sound(name):
    if not state.get("audio", True):
        return
    try:
        Audio(resource_path(f"assets/audio/{name}.wav"), loop=False, autoplay=True)
    except Exception:
        pass

ui_objects = []
intro_overlay = None
intro_active = False
intro_elapsed = 0.0
intro_was_skipped = False
screen = "boot"
selected_mode = "Klasik Tur"
selected_map = "Antik Roma Arenası"
player = None
enemies = []
player_hp = 100
boss_hp = 250
score = 0
message_text = None
binding_action = None

MAPS = ["Antik Roma Arenası", "Kadim Çöl Piramidi", "Karlı Savaş Kalesi", "Karanlık Orman Arenası"]
MODES = ["Klasik Tur", "Tepenin Kralı", "Boss Savaşı", "Sonsuz Mod", "Dünya Fethi"]


def track(obj):
    ui_objects.append(obj)
    return obj

def clear_ui():
    global ui_objects
    for obj in ui_objects:
        try:
            destroy(obj)
        except Exception:
            pass
    ui_objects = []

def ui_text(text, x=0, y=0, scale=1.0, color_value=color.rgb(245, 210, 145), origin=(0, 0), parent=camera.ui):
    return track(Text(text=text, parent=parent, position=(x, y), origin=origin, scale=scale, color=color_value, font=resource_path("assets/DejaVuSans.ttf") if Path(resource_path("assets/DejaVuSans.ttf")).exists() else None))

def ui_button(label, x, y, action, width=.42, height=.065, color_value=color.rgb(55, 34, 25)):
    b = Button(text=label, parent=camera.ui, position=(x, y), scale=(width, height), color=color_value, highlight_color=color.rgb(112, 69, 34), pressed_color=color.rgb(150, 96, 42), text_color=color.rgb(255, 220, 157))
    b.on_click = lambda: (play_sound("ui_click"), action())
    return track(b)

def dim_panel(x=0, y=0, width=1.75, height=1.6, alpha=210):
    return track(Entity(parent=camera.ui, model="quad", position=(x, y, .25), scale=(width, height), color=color.rgba(9, 11, 15, alpha)))

def menu_background():
    bg = Entity(parent=camera.ui, model="quad", texture=resource_path("assets/sparta_cover.jpg"), position=(0, 0, .5), scale=(2, 1.125))
    track(bg)
    track(Entity(parent=camera.ui, model="quad", position=(0, 0, .35), scale=(2, 1.125), color=color.rgba(5, 5, 8, 85)))

def unlock(achievement):
    if achievement not in state["achievements"]:
        state["achievements"].append(achievement)
        save_game()

def stop_intro_audio():
    global intro_audio
    try:
        if intro_audio:
            intro_audio.stop()
    except Exception:
        pass

def start_intro():
    global intro_overlay, intro_active, intro_elapsed, intro_was_skipped, screen
    clear_ui()
    screen = "intro"
    intro_active = True
    intro_elapsed = 0.0
    intro_was_skipped = False
    mouse.visible = True
    intro_overlay = track(Entity(parent=camera.ui, model="quad", texture=resource_path("assets/sparta_cover.jpg"), position=(0, 0, .5), scale=(2.05, 1.153)))
    track(Entity(parent=camera.ui, model="quad", position=(0, -.43, .35), scale=(2, .27), color=color.rgba(0, 0, 0, 135)))
    ui_text("SPARTA ARENA • SAVAŞ ALANI UYANIYOR", 0, -.38, .95)
    ui_text("13 saniyelik sinematik açılış", 0, -.47, .68, color.rgb(220, 190, 148))
    ui_button("ATLA  ▶", .78, -.45, finish_intro, width=.27, height=.075, color_value=color.rgb(93, 22, 20))
    try:
        stop_intro_audio()
        intro_audio = Audio(resource_path("assets/audio/intro_theme.wav"), loop=False, autoplay=True, auto_destroy=False)
    except Exception:
        pass

def finish_intro(skipped=False):
    global intro_active, intro_overlay, intro_was_skipped, screen
    if not intro_active:
        return
    intro_active = False
    intro_was_skipped = skipped
    stop_intro_audio()
    state["intro_seen"] = True
    save_game()
    clear_ui()
    intro_overlay = None
    show_main_menu()

def show_main_menu():
    global screen
    screen = "main"
    mouse.visible = True
    mouse.locked = False
    clear_ui()
    menu_background()
    # Menu panel and clear call-to-action buttons.
    dim_panel(.61, -.015, .72, 1.32, 205)
    ui_text("ANA MENÜ", .61, .53, 1.25)
    ui_text(f"ALTIN: {state['gold']}   •   KAZANMA: {state['wins']}", .61, .445, .72, color.rgb(237, 204, 154))
    buttons = [
        ("OYNA", lambda: show_mode_select(), color.rgb(95, 40, 24)),
        ("DÜNYA FETHİ", lambda: show_conquest(), color.rgb(59, 39, 28)),
        ("MAĞAZA", lambda: show_shop(), color.rgb(59, 39, 28)),
        ("İKSİRLER", lambda: show_potions(), color.rgb(59, 39, 28)),
        ("BAŞARIMLAR", lambda: show_achievements(), color.rgb(59, 39, 28)),
        ("TANITIMI OYNAT", lambda: start_intro(), color.rgb(76, 29, 25)),
        ("AYARLAR / KONTROLLER", lambda: show_settings(), color.rgb(59, 39, 28)),
        ("ÇIKIŞ", lambda: application.quit(), color.rgb(38, 30, 29)),
    ]
    for i, (label, action, bc) in enumerate(buttons):
        ui_button(label, .61, .32 - i*.105, action, width=.53, height=.073, color_value=bc)
    ui_text("SPARTA WORLD  •  3D ARENA", -.92, -.48, .55, color.rgb(228, 190, 128), origin=(-.5, 0))
    ui_text("WASD hareket  •  Fare kamera  •  Sol tık saldırı  •  Shift savunma", -.92, -.54, .48, color.rgb(228, 212, 184), origin=(-.5, 0))

def show_mode_select():
    global screen
    screen = "modes"
    clear_ui(); dim_panel(0, 0, 1.25, 1.55, 226)
    ui_text("OYUN MODU SEÇ", 0, .53, 1.5)
    ui_text("Bir mod seç; sonraki ekranda haritanı belirle.", 0, .43, .7, color.rgb(225, 206, 173))
    positions = [(-.34,.22),(.34,.22),(-.34,.02),(.34,.02),(0,-.18)]
    for mode, (x,y) in zip(MODES, positions):
        ui_button(mode.upper(), x, y, lambda m=mode: select_mode(m), width=.52, height=.09)
    ui_button("GERİ", 0, -.43, show_main_menu, width=.3, height=.07)

def select_mode(mode):
    global selected_mode
    selected_mode = mode
    show_map_select()

def show_map_select():
    global screen
    screen = "maps"
    clear_ui(); dim_panel(0,0,1.24,1.55,232)
    ui_text("HARİTA SEÇ", 0, .52, 1.5)
    ui_text(f"MOD: {selected_mode.upper()}", 0, .42, .72, color.rgb(238, 192, 121))
    for i, name in enumerate(MAPS):
        ui_button(name.upper(), 0, .27-i*.145, lambda m=name: launch_game(m), width=.78, height=.09)
    ui_button("GERİ", 0, -.42, show_mode_select, width=.3, height=.07)

def clean_game_entities():
    global player, enemies, message_text
    if player is not None:
        destroy(player); player = None
    for enemy in enemies:
        try: destroy(enemy)
        except Exception: pass
    enemies = []
    if message_text is not None:
        try: destroy(message_text)
        except Exception: pass
        message_text = None

def launch_game(map_name):
    global screen, selected_map, player, enemies, player_hp, boss_hp, score, message_text
    selected_map = map_name
    screen = "game"
    clear_ui(); clean_game_entities()
    mouse.visible = False; mouse.locked = True
    camera.fov = 90
    if map_name == "Karlı Savaş Kalesi":
        arena_color = color.rgb(143, 151, 162)
    elif map_name == "Kadim Çöl Piramidi":
        arena_color = color.rgb(173, 126, 73)
    elif map_name == "Karanlık Orman Arenası":
        arena_color = color.rgb(58, 75, 48)
    else:
        arena_color = color.rgb(132, 94, 61)
    # Keep the arena playable and visually distinct per map.
    for obj in scene.entities:
        if getattr(obj, "model", None) == "cylinder" and getattr(obj, "y", 99) in (-.15, .25, .34):
            try: obj.color = arena_color
            except Exception: pass
    player = Entity(model="cube", color=color.rgb(62, 110, 150), scale=(.85, 1.8, .85), position=(0, .9, -7), collider="box")
    player.hp = 100
    player.rotation_y = 0
    player_hp = 100
    boss_hp = 250
    score = 0
    count = 1 if selected_mode == "Boss Savaşı" else (7 if selected_mode == "Sonsuz Mod" else 4)
    for i in range(count):
        x = (i-(count-1)/2)*2.4
        z = 3 + (i%2)*2
        enemy = Entity(model="cube", color=color.rgb(120, 31, 29), scale=(.9, 1.8, .9), position=(x, .9, z), collider="box")
        enemy.hp = 3 if selected_mode != "Boss Savaşı" else 18
        enemy.is_boss = selected_mode == "Boss Savaşı"
        if enemy.is_boss:
            enemy.scale = (2.4, 3.2, 2.4)
            enemy.color = color.rgb(82, 20, 26)
        enemies.append(enemy)
    ui_text(f"{selected_mode.upper()}  •  {selected_map.upper()}", 0, .48, .82)
    ui_text("WASD: hareket   Fare: bakış   Sol tık: saldırı   Shift: savunma   ESC: menü", 0, -.49, .53, color.rgb(236, 211, 175))
    message_text = track(Text(parent=camera.ui, text="CAN: 100   •   DÜŞMAN: " + str(len(enemies)), position=(-.86,.40), scale=.8, color=color.white))
    camera.position = player.position + Vec3(0, 5.2, -11)
    camera.look_at(player.position + Vec3(0, 1.0, 0))
    if selected_mode == "Dünya Fethi":
        unlock("İlk Sefer")

def game_over(won):
    global screen
    mouse.locked = False; mouse.visible = True
    screen = "game_over"
    clear_ui()
    dim_panel(0,0,1.1,.8,232)
    title = "ZAFER!" if won else "YENİLGİ"
    ui_text(title,0,.18,1.8, color.rgb(246, 202, 120) if won else color.rgb(230, 95, 75))
    if won:
        state["wins"] += 1; state["gold"] += 30; unlock("Arena Galibi")
        if selected_mode == "Boss Savaşı": unlock("Boss Avcısı")
    save_game()
    ui_text("+30 ALTIN" if won else "Bir daha dene!",0,.02,.82)
    ui_button("TEKRAR OYNA",0,-.13,lambda:launch_game(selected_map),width=.45)
    ui_button("ANA MENÜ",0,-.27,show_main_menu,width=.35)

def show_conquest():
    global screen
    screen = "conquest"
    clear_ui(); dim_panel(0,0,1.35,1.52,230)
    ui_text("DÜNYA FETHİ",0,.52,1.45)
    ui_text(f"Fethedilen şehir: {len(state['cities'])}   •   Deniz bölgeleri: {len(state['seas'])}",0,.42,.7)
    regions=["Atina", "Korint", "Truva", "Anadolu", "Mısır"]
    for i,name in enumerate(regions):
        status="✓" if name in state["cities"] else "FETHE GİT"
        ui_button(f"{name.upper()}  —  {status}",-.34,.25-i*.12,lambda n=name:capture_city(n),width=.58,height=.075)
    ui_button("DENİZ FETHİ",.37,.15,show_sea_conquest,width=.42,height=.09)
    ui_button("ŞEHİRLERİM",.37,0,show_cities,width=.42,height=.09)
    ui_button("BALIKÇILIK",.37,-.15,show_fishing,width=.42,height=.09)
    ui_button("GERİ",0,-.48,show_main_menu,width=.3,height=.07)

def capture_city(name):
    if name not in state["cities"]:
        if state["gold"] < 20:
            show_notice("Yeterli altının yok. (20 altın gerekli)", show_conquest); return
        state["gold"] -= 20
        state["cities"].append(name)
        state["gold"] += 15
        unlock("İlk Şehir")
        save_game()
    show_conquest()

def show_cities():
    clear_ui(); dim_panel(0,0,1.15,1.15,232)
    ui_text("ŞEHİRLERİM",0,.38,1.35)
    ui_text("\n".join(state["cities"]) if state["cities"] else "Henüz fethedilen şehir yok.",0,.08,.9)
    ui_button("GERİ",0,-.38,show_conquest,width=.3)

def show_sea_conquest():
    clear_ui(); dim_panel(0,0,1.1,1.1,232)
    ui_text("DENİZ FETHİ",0,.35,1.35)
    seas=["Ege Denizi", "Akdeniz", "Karadeniz"]
    for i,name in enumerate(seas):
        status="✓ FETHEDİLDİ" if name in state["seas"] else "15 ALTINLA KEŞFET"
        ui_button(f"{name}  •  {status}",0,.13-i*.14,lambda n=name:capture_sea(n),width=.75)
    ui_button("GERİ",0,-.38,show_conquest,width=.3)

def capture_sea(name):
    if name not in state["seas"] and state["gold"] >= 15:
        state["gold"] -= 15; state["seas"].append(name); unlock("Denizlere Açıl")
        save_game()
    elif name not in state["seas"]:
        show_notice("15 altın gerekiyor.", show_sea_conquest); return
    show_sea_conquest()

def show_fishing():
    clear_ui(); dim_panel(0,0,1.0,.9,232)
    ui_text("BALIKÇILIK",0,.25,1.4)
    ui_text(f"Yakalanan balık: {state['fish']}",0,.06,.9)
    ui_button("BALIK TUT  (+5–15 ALTIN)",0,-.08,fish_once,width=.58,height=.1)
    ui_button("GERİ",0,-.30,show_conquest,width=.3)

def fish_once():
    amount=random.randint(5,15); state["gold"]+=amount; state["fish"]+=1
    unlock("İlk Balık"); save_game(); show_fishing()

def show_shop():
    global screen
    screen = "shop"
    clear_ui(); dim_panel(0,0,1.15,1.28,232)
    ui_text("SPARTA MAĞAZASI",0,.45,1.35)
    ui_text(f"ALTIN: {state['gold']}",0,.35,.82)
    ui_button("CAN İKSİRİ  •  25 ALTIN",0,.17,lambda:buy_potion("healing",25),width=.62,height=.09)
    ui_button("GÜÇ İKSİRİ  •  50 ALTIN",0,.02,lambda:buy_potion("strength",50),width=.62,height=.09)
    ui_button("KALKAN YÜKSELTME  •  40 ALTIN",0,-.13,lambda:buy_upgrade(40),width=.68,height=.09)
    ui_text("İksirler tek kullanımlıktır; envanterde saklanır.",0,-.28,.58,color.rgb(224,201,165))
    ui_button("GERİ",0,-.44,show_main_menu,width=.3)

def buy_potion(kind, cost):
    if state["gold"] >= cost:
        state["gold"] -= cost; state["potions"][kind] = state["potions"].get(kind,0)+1; save_game()
        show_shop()
    else: show_notice("Yeterli altının yok.", show_shop)

def buy_upgrade(cost):
    if state["gold"] >= cost:
        state["gold"] -= cost; state["shield_level"] = state.get("shield_level",0)+1; save_game()
        show_notice("Kalkan seviyesi yükseltildi!", show_shop)
    else: show_notice("Yeterli altının yok.", show_shop)

def show_potions():
    clear_ui(); dim_panel(0,0,1.05,1.12,232)
    ui_text("İKSİR ENVANTERİ",0,.36,1.35)
    ui_text(f"Can iksiri: {state['potions'].get('healing',0)}",0,.16,.9)
    ui_button("CAN İKSİRİ KULLAN",0,.02,lambda:use_potion("healing"),width=.5)
    ui_text(f"Güç iksiri: {state['potions'].get('strength',0)}",0,-.10,.9)
    ui_button("GÜÇ İKSİRİ KULLAN",0,-.24,lambda:use_potion("strength"),width=.5)
    ui_button("GERİ",0,-.42,show_main_menu,width=.3)

def use_potion(kind):
    count=state["potions"].get(kind,0)
    if count <= 0:
        show_notice("Bu iksirden envanterinde yok.", show_potions); return
    state["potions"][kind]-=1
    if kind == "healing":
        state["last_potion_effect"]="Can iksiri: bir sonraki arenada başlangıç canın 125 olacak."
    else:
        state["last_potion_effect"]="Güç iksiri: bir sonraki saldırı bonusun güçlendirildi."
    save_game(); show_notice(state["last_potion_effect"], show_potions)

def show_achievements():
    clear_ui(); dim_panel(0,0,1.28,1.48,232)
    ui_text("BAŞARIMLAR",0,.49,1.4)
    all_ach=["İlk Sefer", "Arena Galibi", "Boss Avcısı", "İlk Şehir", "Denizlere Açıl", "İlk Balık"]
    for i, name in enumerate(all_ach):
        got = name in state["achievements"]
        ui_text(("✓  " if got else "○  ")+name, -.47, .29-i*.105, .78, color.rgb(243,205,126) if got else color.rgb(163,155,145), origin=(-.5,0))
    ui_button("GERİ",0,-.45,show_main_menu,width=.3)

def show_settings():
    clear_ui(); dim_panel(0,0,1.18,1.36,232)
    ui_text("AYARLAR / KONTROLLER",0,.48,1.25)
    ui_text("Bir kontrolü değiştirmek için yanındaki düğmeye basıp yeni tuşa bas.",0,.37,.62,color.rgb(224,204,171))
    labels=[("forward","İLERİ"),("back","GERİ"),("left","SOLA"),("right","SAĞA"),("block","SAVUNMA")]
    for i,(key,label) in enumerate(labels):
        y=.23-i*.12
        ui_text(f"{label}: {state['controls'].get(key,'?').upper()}",-.34,y,.78,origin=(-.5,0))
        ui_button("TUŞU DEĞİŞTİR",.35,y,lambda k=key:begin_rebind(k),width=.36,height=.07)
    sound_label="SES: AÇIK" if state.get("audio",True) else "SES: KAPALI"
    ui_button(sound_label,0,-.39,toggle_audio,width=.38)
    ui_button("GERİ",0,-.49,show_main_menu,width=.25,height=.055)

def begin_rebind(action):
    global binding_action
    binding_action = action
    clear_ui(); dim_panel(0,0,1.0,.62,240)
    label={"forward":"İLERİ","back":"GERİ","left":"SOLA","right":"SAĞA","block":"SAVUNMA"}.get(action,action)
    ui_text(f"{label} İÇİN YENİ BİR TUŞA BAS",0,.08,.9)
    ui_text("İptal: ESC",0,-.08,.65,color.rgb(222,195,151))

def toggle_audio():
    state["audio"] = not state.get("audio",True); save_game(); show_settings()

def show_notice(msg, back_action):
    clear_ui(); dim_panel(0,0,1.0,.68,240)
    ui_text(msg,0,.06,.78)
    ui_button("TAMAM",0,-.12,back_action,width=.3)


def update():
    global intro_elapsed, intro_active, player_hp, boss_hp, score
    dt = time.dt
    if intro_active:
        intro_elapsed += dt
        if intro_overlay:
            zoom = 2.05 + min(.09, intro_elapsed*.006)
            intro_overlay.scale = (zoom, zoom*9/16)
        if intro_elapsed >= 13:
            finish_intro(False)
        return
    if screen == "game" and player:
        speed = 6.5 * dt
        fwd = 1 if held_keys.get(state["controls"].get("forward","w"),0) else 0
        back = 1 if held_keys.get(state["controls"].get("back","s"),0) else 0
        left = 1 if held_keys.get(state["controls"].get("left","a"),0) else 0
        right = 1 if held_keys.get(state["controls"].get("right","d"),0) else 0
        player.x += (right-left)*speed
        player.z += (fwd-back)*speed
        player.x = max(-13,min(13,player.x)); player.z=max(-13,min(13,player.z))
        # Smooth third-person follow camera.
        target_camera = player.position + Vec3(0, 5.2, -11)
        camera.position = lerp(camera.position, target_camera, min(1,dt*4))
        camera.look_at(player.position + Vec3(0, 1.0, 0))
        for enemy in list(enemies):
            if distance(enemy.position, player.position) > 1.8:
                direction = (player.position - enemy.position).normalized()
                enemy.position += direction * dt * (0.7 if enemy.is_boss else 1.05)
            else:
                if not held_keys.get(state["controls"].get("block","shift"),0):
                    player_hp -= dt * (5 if enemy.is_boss else 2.5)
        if message_text:
            message_text.text=f"CAN: {max(0,int(player_hp))}   •   DÜŞMAN: {len(enemies)}   •   ALTIN: {state['gold']}"
        if player_hp <= 0:
            game_over(False)
        elif not enemies:
            game_over(True)


def input(key):
    global binding_action, player_hp, score
    if binding_action:
        if key == "escape":
            binding_action = None; show_settings(); return
        if key in ("left mouse down", "right mouse down", "middle mouse down"):
            return
        state["controls"][binding_action] = key
        binding_action = None; save_game(); show_settings(); return
    if key == "escape":
        if screen == "game":
            mouse.locked = False; mouse.visible = True
            clean_game_entities(); show_main_menu()
        elif screen == "intro":
            finish_intro(True)
        elif screen != "main":
            show_main_menu()
        return
    if screen == "game" and player and key == "left mouse down":
        play_sound("sword_swish")
        candidates = sorted(enemies, key=lambda e: distance(e.position, player.position))
        if candidates and distance(candidates[0].position, player.position) < 4.2:
            enemy = candidates[0]
            enemy.hp -= 1
            enemy.color = color.rgb(194, 74, 48)
            if enemy.hp <= 0:
                enemies.remove(enemy); destroy(enemy); state["gold"] += 5; score += 1; save_game()
            if selected_mode == "Boss Savaşı" and enemies:
                boss_hp = max(0,boss_hp-15)
        if not enemies:
            game_over(True)

# First launch shows the cinematic once; subsequent launches go straight to menu.
if not state.get("intro_seen", False):
    start_intro()
else:
    show_main_menu()

app.run()
